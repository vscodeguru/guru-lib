﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp_agGrid.UsrCtrl
{
    public partial class agGrid : System.Web.UI.UserControl
    {
        public string GridID { get; set; }
        public string GridDivID = Guid.NewGuid().ToString().Replace("-", "");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnHello_Click(object sender, EventArgs e)
        {
            var h = 1;
            Console.WriteLine(h);
        }
    }
}