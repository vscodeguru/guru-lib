﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp_agGrid.UsrCtrl
{
    public partial class agGrid : System.Web.UI.UserControl
    {
        public string GridID { get; set; }
        public string GridDivID = Guid.NewGuid().ToString().Replace("-", "");
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnHello_Click(object sender, EventArgs e)
        {
            JavaScriptSerializer json_serializer = new JavaScriptSerializer();
            var obj = json_serializer.Deserialize<dynamic>(hfRowValue.Value);
            var CommandEventArgs = new GridViewCommandEventArgs(this, new CommandEventArgs(hfRowEvent.Value, obj));
            OnRowCommand(sender, CommandEventArgs);
        }

        public event GridViewCommandEventHandler RowCommand;
        protected virtual void OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (RowCommand != null)
            {
                RowCommand(this, e);
            }
        }
    }
}