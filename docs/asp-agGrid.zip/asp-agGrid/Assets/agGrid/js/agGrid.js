function apiGet(url, header) {
    return new Promise(function (myResolve, myReject) {
        try {
            $.ajax({
                type: 'GET',
                url: url,
                header: header,
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                beforeSend: function (xhr) {
                    if (header) {
                        var keys = Object.keys(header);
                        keys.forEach((key) => {
                            xhr.setRequestHeader(key, header[key]);
                        });
                    }
                },
                success: function (response) {
                    myResolve(response);
                },
                failure: function (response) {
                    myReject(response);
                },
                error: function (response) {
                    myReject(response);
                },
            });
        } catch (error) {
            console.log(error);
            myReject(error);
        }
    });
}
function apiPost(url, data, header) {
    return new Promise(function (myResolve, myReject) {
        try {
            $.ajax({
                type: 'POST',
                url: url,
                data: data,
                header: header,
                contentType: 'application/json; charset=utf-8',
                success: (response) => {
                    myResolve(response);
                },
                error: (error) => {
                    myReject(error);
                },
            });
        } catch (error) {
            myReject(error);
        }
    });
}



class ServerSideDatasource {
    constructor(gridURL) {
        this.gridURL = gridURL;
    }
    getRows(params) {
        apiGet('http://192.168.0.116:45456' + this.gridURL, {
            metaData: JSON.stringify(params.request),
            authorization: agGridEx.getAuthorizationToken(),
        }).then((response) => {
            params.successCallback(response.ResultsForPage, response.RowCount);
            setTimeout(() => {
                agGridEx.restoreState();
                agGridEx.sizeToFit();
            }, 200);
        });
    }
}

class OptionsRenderer {
    init(params) {
        this.eGui = document.createElement('div');
        this.eGui.className = 'agGrid-Options';
        let btnID = 'menu-btn-' + agGridEx.uuidv4();
        this.eGui.innerHTML = `
            <button type="button" id="`+ btnID + `" data-node-id="` + params.node.id + `" class="agGrid-Option-Btn">
                <span class="ag-icon ag-icon-menu"></span>
            </button>
        `
        setTimeout(() => {
            this.eButton = this.eGui.querySelector('#' + btnID);

            agGridEx.contextMenu.data.forEach(itm => {
                itm.action = function (e, selector) {
                    agGridEx.invokeServerEvent(itm.text, selector.attr("data-node-id"));
                }
            });
            context.attach(this.eButton, agGridEx.contextMenu);
        }, 100);
    }
    getGui() {
        return this.eGui;
    }
}


class agGridEx {
    static gridOptions = {};
    static gridURL = '';
    static options = {
        noRowsOverlayComponent: 'customNoRowsOverlay',
        columnDefs: [],
        defaultColDef: {
            menuTabs: ['generalMenuTab', 'filterMenuTab'],
            sortable: true,
            resizable: false,
            filter: 'agTextColumnFilter',
            flex: 1,
            minWidth: 90,
        },
        suppressRowClickSelection: true,
        suppressMovableColumns: true,
        suppressDragLeaveHidesColumns: true,
        suppressPropertyNamesCheck: true,
        enableColResize: false,
        rowHeight: 31,
        rowSelection: 'multiple',
        onGridReady: function (event) {
            const server = new ServerSideDatasource(agGridEx.gridURL);
            event.api.setServerSideDatasource(server);
        },
        components: {
            optionsRenderer: OptionsRenderer,
        },
        getChildCount: function (data) {
            return data ? data.childCount : undefined;
        },
        processRowPostCreate: function (data) {
            if (window?.agGridState?.expandedRows?.findIndex(row => row.id === data.node.id) >= 0) {
                setTimeout(function () { agGridEx.gridOptions.api.getRowNode(data.node.id.toString()).setExpanded(true); }, 100)
            }
        }
    };
    static getGridOption = function (GridURL, apiOptions) {
        agGridEx.gridURL = GridURL;
        _.merge(_.keyBy(apiOptions.columnDefs, 'colId'), _.keyBy(agGridEx.options.columnDefs, 'colId'));
        return { ...agGridEx.options, ...apiOptions };
    };
    static saveState = function () {
        try {
            let expandedRows = [];
            agGridEx.gridOptions.api.forEachNode(node => { if (node.expanded) { expandedRows.push(node); } });
            window.agGridState = {
                expandedRows: expandedRows,
                column: agGridEx.gridOptions.columnApi.getColumnState(),
                group: agGridEx.gridOptions.columnApi.getColumnGroupState(),
                filter: agGridEx.gridOptions.api.getFilterModel()
            }
        } catch (e) {
            console.log(e);
            alert(1);
        }
    };
    static restoreState = function () {
        if (window?.agGridState?.column) {
            agGridEx.gridOptions.columnApi.applyColumnState(window.agGridState.column);
        }
        if (window?.agGridState?.group) {
            agGridEx.gridOptions.columnApi.setColumnGroupState(window.agGridState.group);
        }
        if (window?.agGridState?.filter) {
            agGridEx.gridOptions.api.setFilterModel(window.agGridState.filter);
        }
    };
    static sizeToFit = function () {
        agGridEx.gridOptions.api.sizeColumnsToFit();
    };
    static autoSizeAll = function (skipHeader) {
        var allColumnIds = [];
        agGridEx.gridOptions.columnApi.getAllColumns().forEach(function (column) {
            allColumnIds.push(column.colId);
        });

        agGridEx.gridOptions.columnApi.autoSizeColumns(allColumnIds, skipHeader);
    }
    static uuidv4 = function () {
        return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
            (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    }
    static invokeServerEvent = function (event, nodeID) {
        let node = agGridEx.gridOptions.api.getRowNode(nodeID);
        $('#hfRowEvent').val(event);
        $('#hfRowValue').val(JSON.stringify(node.data));
        $('#btnHello').click();
    }
    static getAuthorizationToken = function () {
        return '';
    }
    static init = function (id, agDiv) {
        apiGet('http://192.168.0.116:45456/api/ag-grid/col-def/' + id, { authorization: agGridEx.getAuthorizationToken(), }).then((response) => {
            agGrid.LicenseManager.setLicenseKey(
                '[PROD][v2]-01_May_2030__MTkwMzgyNDAwMDAwMA==a40b3d7226d24f6509736682beab6bc2'
            );
            var gridApiOptions = JSON.parse(response.GridOption);

            // On Init
            var as = new agGrid.Grid(agDiv, agGridEx.getGridOption(response.GridURL, gridApiOptions));
            agGridEx.gridOptions = as.gridOptions;
        });
    }
    static contextMenu = {
        id: 'agGrid-Context-Menu',
        data: []
    }
}