function apiGet(url, header) {
    return new Promise(function (myResolve, myReject) {
        try {
            $.ajax({
                type: 'GET',
                url: url,
                header: header,
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                beforeSend: function (xhr) {
                    if (header) {
                        var keys = Object.keys(header);
                        keys.forEach((key) => {
                            xhr.setRequestHeader(key, header[key]);
                        });
                    }
                },
                success: function (response) {
                    myResolve(response);
                },
                failure: function (response) {
                    myReject(response);
                },
                error: function (response) {
                    myReject(response);
                },
            });
        } catch (error) {
            console.log(error);
            myReject(error);
        }
    });
}
function apiPost(url, data, header) {
    return new Promise(function (myResolve, myReject) {
        try {
            $.ajax({
                type: 'POST',
                url: url,
                data: data,
                header: header,
                contentType: 'application/json; charset=utf-8',
                success: (response) => {
                    myResolve(response);
                },
                error: (error) => {
                    myReject(error);
                },
            });
        } catch (error) {
            myReject(error);
        }
    });
}

function agGridInit(id, agDiv) {
    apiGet('http://192.168.0.116:45456/api/ag-grid/col-def/' + id).then((response) => {
        agGrid.LicenseManager.setLicenseKey(
            '[PROD][v2]-01_May_2030__MTkwMzgyNDAwMDAwMA==a40b3d7226d24f6509736682beab6bc2'
        );
        var gridApiOptions = JSON.parse(response.GridOption);
        // On Grid Ready Event
        gridEventOption = {
            onGridReady: function (event) {
                const server = new ServerSideDatasource(response.GridURL);
                event.api.setServerSideDatasource(server);
                setTimeout(() => {
                    agGridRestoreState()
                }, 100);

            },
            getChildCount: function (data) {
                return data ? data.childCount : undefined;
            },
            processRowPostCreate: function (data) {
                if (window?.rowExpanState?.findIndex(row => row.id === data.node.id) >= 0) {
                    setTimeout(function () { gridOptions.api.getRowNode(data.node.id.toString()).setExpanded(true); }, 100)
                    
                }
            }
        };
        gridOptions = { ...agGridEx.options, ...gridEventOption, ...gridApiOptions };
        // On Init
        new agGrid.Grid(agDiv, gridOptions);
    });
}

function sizeToFit() {
    gridOptions.api.sizeColumnsToFit();
}
function autoSizeAll(skipHeader) {
    var allColumnIds = [];
    gridOptions.columnApi.getAllColumns().forEach(function (column) {
        allColumnIds.push(column.colId);
    });

    gridOptions.columnApi.autoSizeColumns(allColumnIds, skipHeader);
}

class agGridEx {
    static options = {
        noRowsOverlayComponent: 'customNoRowsOverlay',
        defaultColDef: {
            menuTabs: ['generalMenuTab', 'filterMenuTab'],
            sortable: true,
            resizable: false,
            filter: 'agTextColumnFilter',
            flex: 1,
            minWidth: 90,
        },
        suppressRowClickSelection: true,
        suppressMovableColumns: true,
        suppressDragLeaveHidesColumns: true,
        suppressPropertyNamesCheck: true,
        enableColResize: false,
        rowHeight: 31,
        rowSelection: 'multiple',
    };
}

class ServerSideDatasource {
    constructor(gridURL) {
        this.gridURL = gridURL;
    }
    getRows(params) {
        apiGet('http://192.168.0.116:45456' + this.gridURL, {
            metaData: JSON.stringify(params.request),
        }).then((response) => {
            params.successCallback(response.ResultsForPage, response.RowCount);
            setTimeout(() => {
                sizeToFit();
            }, 100);
        });
    }
}



function agGridSaveState() {
    expandedRows = [];
    gridOptions.api.forEachNode(node => { if (node.expanded) { expandedRows.push(node); } });
    window.rowExpanState = expandedRows;
    window.colState = gridOptions.columnApi.getColumnState();
    window.groupState = gridOptions.columnApi.getColumnGroupState();
    window.filterState = gridOptions.api.getFilterModel();
    console.log('column state saved');
}
function agGridRestoreState() {
    if (window.colState) {
        gridOptions.columnApi.setColumnState(window.colState);
    }
    if (window.groupState) {
        gridOptions.columnApi.setColumnGroupState(window.groupState);
    }
    if (window.filterState) {
        gridOptions.api.setFilterModel(window.filterState);
    }
}

function getParentID(node, key) {
    if (!key) {
        key = '';
    }
    if (node?.parent?.key) {
        key = node?.parent.key + '-' + key;
        return getParentID(node?.parent, key);
    }
    return key
}